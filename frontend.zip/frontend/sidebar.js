// Aurelius sidebar for the Dental Voice Agent dashboard.
// Add data-page="appointments|availability|history" to <body>.
// Expects an element with id="sidebar-root" where the sidebar will be inserted.
(function () {
  var TABS = [
    { id: 'dashboard',    jack: 'DB', label: 'Dashboard',        href: 'dashboard.html' },
    { id: 'appointments', jack: 'AP', label: 'Appointments',   href: 'appointments.html' },
    { id: 'availability', jack: 'AV', label: 'Set Availability', href: 'availability.html' },
    { id: 'history',      jack: 'CH', label: 'Call History',    href: 'history.html' }
  ];

  var active = document.body.getAttribute('data-page');

  var linksHtml = TABS.map(function (t) {
    var isActive = t.id === active;
    return (
      '<a href="' + t.href + '" id="nav-' + t.id + '" data-label="' + t.label.toLowerCase() + '"' +
      (isActive ? ' aria-current="page"' : '') +
      ' class="sidebar-tab flex items-center gap-4 px-4 py-4 transition-all ' +
        (isActive ? 'text-gold nav-item-active' : 'text-slate-500 hover:text-white group') + '">' +
        '<span class="w-6 h-6 flex items-center justify-center border ' +
          (isActive ? 'border-current' : 'border-slate-800 group-hover:border-gold transition-colors') +
          ' text-[9px] font-bold">' + t.jack + '</span>' +
        '<span class="text-sm tracking-wide font-medium">' + t.label + '</span>' +
      '</a>'
    );
  }).join('');

  var html =
    '<button id="sidebarToggle" type="button" title="Toggle menu" ' +
      'class="fixed top-6 left-6 z-[70] w-10 h-10 flex items-center justify-center bg-[#0D1016] border border-[#1E232D] text-slate-400 hover:text-gold hover:border-gold/40 transition-colors">' +
      '<iconify-icon icon="lucide:panel-left" class="text-lg"></iconify-icon>' +
    '</button>' +
    '<aside id="aureliusSidebar" class="w-80 bg-[#0D1016] border-r border-[#1E232D] flex flex-col z-50 shrink-0 overflow-hidden transition-all duration-300 ease-out">' +
      '<div class="p-10 pb-12 flex flex-col items-start w-80">' +
        '<div class="flex items-center gap-3 mb-2">' +
          '<div class="w-8 h-8 rounded-full border border-gold flex items-center justify-center relative">' +
            '<div class="w-4 h-4 rounded-full bg-emerald-500 animate-pulse" id="aureliusStatusDot"></div>' +
            '<div class="absolute inset-0 border border-emerald-500/30 rounded-full scale-125" id="aureliusStatusRing"></div>' +
          '</div>' +
          '<span class="serif-font text-xl font-semibold tracking-wide text-white">Aurelius</span>' +
        '</div>' +
        '<span class="text-[10px] uppercase tracking-[0.4em] text-gold-muted font-bold ml-1">Faizan\'s Dental Clinic</span>' +
      '</div>' +

      '<nav class="flex-1 overflow-y-auto custom-scrollbar px-6 space-y-4 w-80">' +
        '<div class="relative mb-1">' +
          '<iconify-icon icon="lucide:search" class="absolute left-3 top-1/2 -translate-y-1/2 text-slate-600 text-sm"></iconify-icon>' +
          '<input type="text" id="sidebarSearchInput" placeholder="Search menu..." autocomplete="off" ' +
            'class="w-full bg-[#050608] border border-[#1E232D] py-2 pl-9 pr-3 text-xs tracking-wide text-white focus:outline-none focus:border-gold/40 transition-all">' +
        '</div>' +
        '<div class="px-2 mb-2">' +
          '<span class="text-[9px] font-bold uppercase tracking-[0.3em] text-slate-600">Front Desk</span>' +
        '</div>' +
        linksHtml +
      '</nav>' +

      '<div class="p-8 border-t border-[#1E232D] space-y-4 w-80">' +
        '<button id="themeToggle" class="w-full flex items-center justify-between text-slate-500 hover:text-gold transition-colors">' +
          '<span class="flex items-center gap-3">' +
            '<iconify-icon icon="lucide:moon-star" id="themeIcon" class="text-base"></iconify-icon>' +
            '<span class="text-[10px] uppercase tracking-widest font-bold" id="themeLabel">Dark Mode</span>' +
          '</span>' +
          '<span class="w-11 h-6 rounded-full border border-[#1E232D] relative shrink-0 transition-colors duration-300" id="themeSwitchTrack">' +
            '<span class="absolute top-0.5 left-0.5 w-4.5 h-4.5 rounded-full bg-white shadow-md transition-transform duration-300" id="themeSwitchKnob" style="width:18px;height:18px;"></span>' +
          '</span>' +
        '</button>' +
        '<button id="logoutBtn" class="w-full flex items-center gap-3 text-slate-500 hover:text-amber-500 transition-colors">' +
          '<iconify-icon icon="lucide:log-out" class="text-base"></iconify-icon>' +
          '<span class="text-[10px] uppercase tracking-widest font-bold">Log Out</span>' +
        '</button>' +
        '<div class="flex items-center gap-3">' +
          '<span class="relative flex w-2 h-2">' +
            '<span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-500 opacity-60"></span>' +
            '<span class="relative inline-flex rounded-full w-2 h-2 bg-emerald-500 shadow-[0_0_8px_2px_rgba(16,185,129,0.6)]"></span>' +
          '</span>' +
          '<span class="text-[10px] uppercase tracking-widest text-slate-500 font-bold">Synchronized</span>' +
        '</div>' +
      '</div>' +
    '</aside>';

  document.addEventListener('DOMContentLoaded', function () {
    var root = document.getElementById('sidebar-root');
    if (root) root.outerHTML = html;

    window.Aurelius.setTheme(localStorage.getItem('aureliusTheme') === 'light' ? 'light' : 'dark');

    if (sessionStorage.getItem('aureliusStatus') === 'error') {
      window.Aurelius.setStatus('error');
    }

    var themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
      themeToggle.addEventListener('click', function () {
        var isLight = document.documentElement.getAttribute('data-theme') === 'light';
        window.Aurelius.setTheme(isLight ? 'dark' : 'light');
      });
    }

    var sidebarSearch = document.getElementById('sidebarSearchInput');
    if (sidebarSearch) {
      sidebarSearch.addEventListener('input', function () {
        var q = this.value.trim().toLowerCase();
        document.querySelectorAll('.sidebar-tab').forEach(function (tab) {
          var label = tab.getAttribute('data-label') || '';
          tab.classList.toggle('hidden', !!q && label.indexOf(q) === -1);
        });
      });
    }

    var logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
      logoutBtn.addEventListener('click', function () {
        localStorage.removeItem('dentalAuth');
        window.location.href = 'login.html';
      });
    }

    var sidebar = document.getElementById('aureliusSidebar');
    var toggleBtn = document.getElementById('sidebarToggle');

    function openSidebar() {
      if (sidebar) {
        sidebar.classList.remove('w-0', 'border-r-0');
        sidebar.classList.add('w-80');
      }
      sessionStorage.setItem('aureliusSidebarOpen', 'true');
    }
    function closeSidebar() {
      if (sidebar) {
        sidebar.classList.remove('w-80');
        sidebar.classList.add('w-0', 'border-r-0');
      }
      sessionStorage.setItem('aureliusSidebarOpen', 'false');
    }
    function toggleSidebar() {
      if (sidebar && sidebar.classList.contains('w-0')) openSidebar();
      else closeSidebar();
    }

    if (toggleBtn) toggleBtn.addEventListener('click', toggleSidebar);

    var remembered = sessionStorage.getItem('aureliusSidebarOpen');
    if (remembered === 'false') closeSidebar();
    else openSidebar();
  });

  window.Aurelius = window.Aurelius || {};
  window.Aurelius.setTheme = function (mode) {
    document.documentElement.setAttribute('data-theme', mode);
    localStorage.setItem('aureliusTheme', mode);
    var icon = document.getElementById('themeIcon');
    var label = document.getElementById('themeLabel');
    var knob = document.getElementById('themeSwitchKnob');
    var track = document.getElementById('themeSwitchTrack');
    if (icon) icon.setAttribute('icon', mode === 'light' ? 'lucide:sun' : 'lucide:moon-star');
    if (label) label.textContent = mode === 'light' ? 'Light Mode' : 'Dark Mode';
    if (knob) knob.style.transform = mode === 'light' ? 'translateX(20px)' : 'translateX(0)';
    if (track) track.style.background = mode === 'light' ? 'rgba(166,124,61,0.35)' : '#050608';
  };

  window.Aurelius.setTheme(localStorage.getItem('aureliusTheme') === 'light' ? 'light' : 'dark');

  // Auth guard: every dashboard page (not login.html) requires dentalAuth flag set.
  if (document.body.getAttribute('data-page') && window.location.pathname.indexOf('login.html') === -1) {
    if (localStorage.getItem('dentalAuth') !== 'true') {
      window.location.href = 'login.html';
    }
  }

  window.Aurelius.errorWithRetry = function (el, message, retryFn) {
    el.classList.remove('flex', 'items-center', 'gap-2');
    el.innerHTML =
      '<span class="flex items-center gap-2 text-slate-500">' +
        '<iconify-icon icon="lucide:alert-circle" class="text-amber-500/70"></iconify-icon>' +
        '<span>' + message + '</span>' +
        '<button type="button" class="aurelius-retry-btn inline-flex items-center gap-1 ml-1 text-[10px] uppercase tracking-widest font-bold text-gold-muted hover:text-gold transition-colors">' +
          '<iconify-icon icon="lucide:refresh-cw"></iconify-icon>Retry' +
        '</button>' +
      '</span>';
    var btn = el.querySelector('.aurelius-retry-btn');
    if (btn && typeof retryFn === 'function') {
      btn.addEventListener('click', function () {
        var icon = btn.querySelector('iconify-icon');
        if (icon) icon.classList.add('animate-spin');
        btn.disabled = true;
        retryFn();
      });
    }
  };

  window.Aurelius.setStatus = function (state) {
    var dot = document.getElementById('aureliusStatusDot');
    var ring = document.getElementById('aureliusStatusRing');
    if (!dot || !ring) return;
    if (state === 'error') {
      dot.classList.remove('bg-emerald-500');
      dot.classList.add('bg-amber-500');
      ring.classList.remove('border-emerald-500/30');
      ring.classList.add('border-amber-500/30');
      sessionStorage.setItem('aureliusStatus', 'error');
    } else {
      dot.classList.remove('bg-amber-500');
      dot.classList.add('bg-emerald-500');
      ring.classList.remove('border-amber-500/30');
      ring.classList.add('border-emerald-500/30');
      sessionStorage.removeItem('aureliusStatus');
    }
  };
})();
